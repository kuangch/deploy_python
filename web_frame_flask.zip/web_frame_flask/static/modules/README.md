angularjs:1.3.9
bootstrap:3.3.4
jquery:3.1.0
jqueryUI:1.11.4
intro:1.1.1
jspanel:2.5.5